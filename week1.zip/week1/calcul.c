#include <cs50.h>
#include <stdio.h>

int main(void)
{
    printf("%i\n", get_int("x: ")  + get_int("y: "));
}
